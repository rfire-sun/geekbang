package io.kimmking.kmq.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KmqApplicationTests {

    @Test
    void contextLoads() {
    }

}
